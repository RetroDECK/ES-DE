# Slate for ES-DE - credits

The Slate theme is based on [recalbox-multi](https://gitlab.com/recalbox/recalbox-themes) by the Recalbox community, prior to their license change in 2018.

Some graphics from the [Carbon](https://github.com/RetroPie/es-theme-carbon) theme by Rookervik.

Some console and controller vector graphics by Bezza191.

Some logotype graphics by Dan Patrick.
