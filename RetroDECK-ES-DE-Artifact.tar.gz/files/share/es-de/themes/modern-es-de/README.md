# Modern for ES-DE (modern-es-de)

The following options are included:

4 variants:

- Textlist with videos
- Textlist without videos
- Textlist with videos (legacy)
- Textlist without videos (legacy)

2 color schemes:

- Dark
- Light

2 font sizes:

- Medium
- Large

4 aspect ratios:

- 16:9
- 16:10
- 4:3
- 21:9

3 transitions:

- Instant
- Instant and slide
- Instant and fade

Credits and license information can be found next to this file.
