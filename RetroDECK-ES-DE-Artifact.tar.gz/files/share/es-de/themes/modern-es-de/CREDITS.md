# Modern for ES-DE - credits

The Modern theme is based on [es-theme-switch](https://github.com/lilbud/es-theme-switch) by lilbud, and it was modified for ES-DE by Sophia Hadash.

Default [carousel icons](https://github.com/szymon-kulak/es-de-moderntheme-nsoicons) by Szymon Kulak.

[Nintendo Switch UI Font](https://www.cufonfonts.com/font/nintendo-switch-ui) by MH1.

Some logotype graphics by Dan Patrick.
