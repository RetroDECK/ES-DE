# Slate for ES-DE (slate-es-de)

The following options are included:

2 variants:

- Textlist with videos
- Textlist without videos

2 color schemes:

- Dark
- Light

2 font sizes:

- Medium
- Large

4 aspect ratios:

- 16:9
- 16:9 vertical
- 4:3
- 4:3 vertical

3 transitions:

- Slide
- Instant
- Fade

Credits and license information can be found next to this file.
