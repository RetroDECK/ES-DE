# ES-DE - Missing slate-es-de theme assets

* ags: Adventure Game Studio Game Engine - consolegame.svg, controller.svg
* amigacd32: Amiga CD32 - consolegame.svg, controller.svg
* amstradcpc - Amstrad CPC - controller.svg
* android: Google Android - consolegame.svg, controller.svg
* androidapps: Android Apps - consolegame.svg, controller.svg
* androidgames: Android Games - consolegame.svg, controller.svg
* apple2gs: Apple IIGS - consolegame.svg, controller.svg
* arcadia: Emerson Arcadia 2001 - consolegame.svg, controller.svg
* archimedes: Acorn Archimedes - consolegame.svg, controller.svg
* arduboy: Arduboy Miniature Game System - consolegame.svg, controller.svg
* astrocade: Bally Astrocade - consolegame.svg, controller.svg
* atari5200: Atari 5200 - consolegame.svg, controller.svg
* atari800: Atari 800 - consolegame.svg, controller.svg
* atarijaguar: Atari Jaguar - consolegame.svg, controller.svg
* atarijaguarcd: Atari Jaguar CD - consolegame.svg, controller.svg
* atarist: Atari ST - controller.svg
* atarixe: Atari XE - consolegame.svg, controller.svg
* atomiswave: Sammy Corporation Atomiswave - consolegame.svg
* auto-allgames - customized colors, consolegame.svg, (uses temporary art)
* auto-favorites - customized colors, consolegame.svg, (uses temporary art)
* auto-lastplayed - customized colors, consolegame.svg, (uses temporary art)
* bbcmicro: Acorn Computers BBC Micro - consolegame.svg, controller.svg
* cdimono1: Philips CD-i - consolegame.svg, controller.svg
* cdtv: Commodore CDTV - consolegame.svg, controller.svg
* chailove: ChaiLove Game Engine - consolegame.svg, controller.svg
* channelf: Fairchild Channel F - consolegame.svg, controller.svg
* coco: Tandy Color Computer - consolegame.svg, controller.svg
* consolearcade: Console Arcade Systems - consolegame.svg, controller.svg
* cps: Capcom Play System - consolegame.svg, controller.svg
* cps1: Capcom Play System I - consolegame.svg, controller.svg
* cps2: Capcom Play System II - consolegame.svg, controller.svg
* cps3: Capcom Play System III - consolegame.svg, controller.svg
* crvision: VTech CreatiVision - consolegame.svg, controller.svg
* custom-collections - customized colors, consolegame.svg, (uses temporary art)
* daphne: Daphne Arcade Laserdisc Emulator - consolegame.svg, controller.svg
* desktop: Desktop Applications - consolegame.svg, controller.svg
* dragon32: Dragon Data Dragon 32 - consolegame.svg, controller.svg
* easyrpg: EasyRPG Game Engine - consolegame.svg, controller.svg
* electron: Acorn Electron - consolegame.svg, controller.svg
* emulators: Emulators - consolegame.svg, controller.svg
* epic: Epic Games Store - consolegame.svg, controller.svg
* flash: Adobe Flash - consolegame.svg, controller.svg
* fm7: Fujitsu FM-7 - consolegame.svg, controller.svg
* fmtowns: Fujitsu FM Towns - consolegame.svg, controller.svg
* fpinball: Future Pinball - consolegame.svg, controller.svg
* gamate: Bit Corporation Gamate - consolegame.svg
* gamecom: Tiger Electronics Game.com - consolegame.svg
* gmaster: Hartung Game Master - consolegame.svg
* gx4000: Amstrad GX4000 - consolegame.svg, controller.svg
* intellivision: Mattel Electronics Intellivision - consolegame.svg, controller.svg
* j2me: Java 2 Micro Edition (J2ME) - consolegame.svg, controller.svg
* kodi: Kodi Home Theatre Software - consolegame.svg, controller.svg
* laserdisc: LaserDisc Games - consolegame.svg, controller.svg
* lcdgames: LCD Handheld Games - consolegame.svg
* lowresnx: LowRes NX Fantasy Console - consolegame.svg
* lutris: Lutris Open Gaming Platform - consolegame.svg, controller.svg
* macintosh: Apple Macintosh - consolegame.svg, controller.svg
* megaduck: Creatronic Mega Duck - consolegame.svg
* mess: Multi Emulator Super System - consolegame.svg, controller.svg
* model2: Sega Model 2 - consolegame.svg, controller.svg
* model3: Sega Model 3 - consolegame.svg, controller.svg
* moto: Thomson MO/TO Series - consolegame.svg, controller.svg
* msxturbor: MSX Turbo R - consolegame.svg, controller.svg
* mugen: M.U.G.E.N Game Engine - consolegame.svg, controller.svg
* multivision: Othello Multivision - consolegame.svg, controller.svg
* n64dd: Nintendo 64DD - consolegame.svg
* naomi: Sega NAOMI - consolegame.svg
* naomi2: Sega NAOMI 2 - consolegame.svg
* naomigd: Sega NAOMI GD-ROM - consolegame.svg
* neogeocd: SNK Neo Geo CD - consolegame.svg, controller.svg
* neogeocdjp: SNK Neo Geo CD - consolegame.svg, controller.svg
* ngage: Nokia N-Gage - consolegame.svg
* openbor: OpenBOR Game Engine - consolegame.svg, controller.svg
* oric: Tangerine Computer Systems Oric - consolegame.svg, controller.svg
* palm: Palm OS - consolegame.svg, controller.svg
* pc88: NEC PC-8800 Series - consolegame.svg
* pc98: NEC PC-9800 Series - consolegame.svg
* pcarcade: PC Arcade Systems - consolegame.svg, controller.svg
* pcfx: NEC PC-FX - consolegame.svg, controller.svg
* pico8: PICO-8 Fantasy Console - consolegame.svg, controller.svg
* plus4: Commodore Plus/4 - consolegame.svg, controller.svg
* pokemini: Nintendo Pokémon Mini - consolegame.svg, controller.svg
* ports: Ports - consolegame.svg, controller.svg
* ps4: Sony PlayStation 4 - consolegame.svg, controller.svg
* pv1000: Casio PV-1000 - consolegame.svg, controller.svg
* quake: Quake - consolegame.svg, controller.svg
* samcoupe: MGT SAM Coupé - consolegame.svg
* satellaview: Nintendo Satellaview - consolegame.svg
* scv: Epoch Super Cassette Vision - consolegame.svg, controller.svg
* sgb: Nintendo Super Game Boy - consolegame.svg
* solarus: Solarus Game Engine - consolegame.svg
* spectravideo: Spectravideo - consolegame.svg, controller.svg
* steam: Valve Steam - consolegame.svg, controller.svg
* stv: Sega Titan Video Game System - consolegame.svg, controller.svg
* sufami: Bandai SuFami Turbo - consolegame.svg
* supervision: Watara Supervision - consolegame.svg
* supracan: Funtech Super A'Can - consolegame.svg, controller.svg
* symbian: Symbian - consolegame.svg, controller.svg
* tanodragon: Tano Dragon - consolegame.svg, controller.svg
* ti99: Texas Instruments TI-99 - consolegame.svg
* tic80: TIC-80 Fantasy Computer - consolegame.svg, controller.svg
* to8: Thomson TO8 - consolegame.svg, controller.svg
* triforce: Namco-Sega-Nintendo Triforce - consolegame.svg, controller.svg
* trs-80: Tandy TRS-80 - consolegame.svg, controller.svg
* type-x: Taito Type X - consolegame.svg, controller.svg
* uzebox: Uzebox Open Source Console - consolegame.svg
* vectrex: GCE Vectrex - consolegame.svg (needs simplification as it takes a long time to rasterize)
* videopac: Philips Videopac G7000 - update all info and graphics to differentiate European version from USA version
* virtualboy: Nintendo Virtual Boy - consolegame.svg (needs simplification as it takes a long time to rasterize)
* vpinball: Visual Pinball - consolegame.svg, controller.svg
* vsmile: VTech V.Smile - consolegame.svg, controller.svg
* wasm4: WASM-4 Fantasy Console - consolegame.svg, controller.svg
* windows: Microsoft Windows - consolegame.svg, controller.svg
* windows3x: Microsoft Windows 3.x - consolegame.svg, controller.svg
* windows9x: Microsoft Windows 9x - consolegame.svg, controller.svg
* x1:  Sharp X1 - consolegame.svg
* x68000: Sharp X68000 - consolegame.svg (image of actual console)
* zmachine: Infocom Z-machine - consolegame.svg
* zxnext: Sinclair ZX Spectrum Next - consolegame.svg, controller.svg
